# Herd-Mentality-Simulation
This project explores how individual behaviors influence group dynamics through three interactive simulations built with p5.js
